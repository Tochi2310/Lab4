//DNA class
public class DNA {
private Node first;
private Node last;
private String sequence;   

// constructor
public DNA(String seq) {
sequence = seq;
first = new Node(String.valueOf(seq.charAt(0)), null);
Node next = first;
for(int i = 1; i < seq.length(); i++) {
next.setNext(new Node(String.valueOf(seq.charAt(i)), null));
next = next.getNext();
}
last = next;
}

// Node class
class Node {
private String letter;   
private Node next;   

// constructor
Node(String letter, Node next) {
this.letter = letter;
this.next = next;
}

// get next letter Node
Node getNext() { return next; }

// set next letter Node
Node setNext(Node next) { return this.next = next; }
//get current letter
String getLetter() { return letter; }
//get current letter
String setLetter(String letter) { return this.letter = letter; }

}

// get complete sequence in String form
public String getSequence() {
Node next = first;
String seq = "";
while(next != null) {
seq += next.getLetter();
next = next.getNext();
}
return seq;
}

// print sequence
public void print() {
Node next = first;
int i = 1;
while(next != null) {
System.out.print(next.getLetter());
i++;
next = next.getNext();
}
System.out.println();
}

// set empty sequence
public void setEmpty() {
first = null;
last = null;
}

}

