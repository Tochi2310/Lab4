// code to handle the command affecting the DNA list
public class CommandLine {
public static void processor(DnaList list, String commandLine) {
String[] command = commandLine.split("\\s+"); // creates a list based on the line of code, and then splits it based on the spaces
  
//switching command to find appropriate command
switch(command[0]) {
case "insert":              // if the command is insert, then insert
list.insert(Integer.parseInt(command[1]), command[2], command[3]);
break;
case "print":   // if the command is print
if(command.length == 2 ) {  // if it is to print the whole LinkedList then print the whole LinkedList
list.print(Integer.parseInt(command[1]));
} else {
list.print();
}
break;
case "remove":  // if the command is remove, then remove
list.remove(Integer.parseInt(command[1]));
break;
case "clip": // if the command is clip, then clip
list.clip(Integer.parseInt(command[1]),Integer.parseInt(command[2]), Integer.parseInt(command[3]));
break;
case "copy":  // if the command is copy, then copy
list.copy(Integer.parseInt(command[1]), Integer.parseInt(command[2]));
break;
case "transcribe":   // if the command is transcribe, then transcribe
list.transcribe(Integer.parseInt(command[1]));
break;
default:          // if the command is invalid, then print the error message and continue
System.out.println("Invalid command line"); 
}
  
}
}