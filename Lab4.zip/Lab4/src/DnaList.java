import java.io.File; // Import the File class
import java.io.FileNotFoundException; // Import this class to handle errors
import java.util.Scanner; // Import the Scanner class to read text files

// enumerator for DNA, RNA, and empty sequence that has not been filled
enum Type {
DNA, RNA, NONE
}

public class DnaList {
private DNA[] ArraySequence;
private Type[] ArrayType;
private int size;
  
// constructor
public DnaList(int size) {
ArraySequence = new DNA[size];
ArrayType = new Type[size];
for(int i = 0; i < size; i ++) {
ArraySequence[i] = null;
ArrayType[i] = Type.NONE;
}
this.size = size;
}

// check if the sequence is RNA by going over each of letter
public boolean isRNA(String sequence) {
for(int i = 0; i < sequence.length(); i++) {
String letter = sequence.charAt(i) + "";
switch(letter) {
case "A":
case "U":
case "G":
case "C":
break;
default:
return false;
}
}
return true;
}

// check if the sequence is DNA by going over each letter
public boolean isDNA(String sequence) {
for(int i = 0; i < sequence.length(); i++) {
String letter = sequence.charAt(i) + "";
switch(letter) {
case "A":
case "T":
case "G":
case "C":
break;
default:
return false;
}
}
return true;
}

// insert into a specified position inside array
public void insert(int pos, String type, String sequence) {
// handles wrong position case
if(pos >= size) { System.out.println("Position exceeded sequence default size");}
else {
// check RNA or DNA
switch(type) {
case "RNA":
if(isRNA(sequence)) {
ArraySequence[pos] = new DNA(sequence);
ArrayType[pos] = Type.RNA;
} else { 
System.out.println("Error occured while inserting");
}
break;
case "DNA":
if(isDNA(sequence)) {
ArraySequence[pos] = new DNA(sequence);
ArrayType[pos] = Type.DNA;
} else {
System.out.println("Error occured while inserting");
}
break;
default:
System.out.println("Error: invalid type input, please choose either RNA or DNA");
}
}
}
  
// remove DNA or RNA at specified position
public DNA remove(int pos) {
if(pos >= size) {
System.out.println("Position exceeded default sequence size");
return null;
}
else if(ArrayType[pos] == Type.NONE) {
System.out.println("No sequence to remove at specified location");
return null;
} else {
DNA remove = ArraySequence[pos];
ArraySequence[pos] = null;
ArrayType[pos] = Type.NONE;
return remove;
}
}


// print out available sequence inside array
public void print() {
int i = 0;
while(i < size) {
if(ArrayType[i] != Type.NONE) {
System.out.printf("%d\t%s\t%s", i, ArrayType[i], ArraySequence[i].getSequence());
System.out.println();
}
i++;
}
}

// print out sequence at specified position
public void print(int pos) {
if(pos >= size) { System.out.println("Position exceeded sequence default size");}
else if(ArrayType[pos] == Type.NONE) {// if the position isn't valid, then print the error message and exit
System.out.println("No sequence to print at specified position");
} else {
System.out.printf("%s\t%s",ArrayType[pos], ArraySequence[pos].getSequence());
System.out.println();
}
}

// clip function
public void clip(int pos, int start, int end) {
if(pos >= size) { System.out.println("Position exceeded sequence default size");}
else if(ArrayType[pos] == Type.NONE) { System.out.println("No sequence to clip at specified position"); }
else if(start < 0) { System.out.println("Invalid start position"); } // if the start is invalid, then print the error message and exit
else if(start > ArraySequence[pos].getSequence().length()) { System.out.println("Start position is out of bounds"); }  // if the size is less than the position or there isn't a sequence at the position, then print the error message and exit
else if(end > ArraySequence[pos].getSequence().length()) { System.out.println("End position is out of bounds"); }   // if the end is invalid, then print the error message and exit
else if(start > end) { ArraySequence[pos].setEmpty();}  // if the end is less than the start, then delete the sequence
else {
ArraySequence[pos] = new DNA(ArraySequence[pos].getSequence().substring(start, end+1));
}
}

// copy from pos1 to pos2
public void copy(int pos1, int pos2) {
if(pos1 >= size || pos2 >= size) { System.out.println("Position exceeded sequence default size");}
else if(ArrayType[pos1] == Type.NONE) { System.out.println("No sequence to copy at specified position");}
else {
// setting a new DNA slot at that spot
ArraySequence[pos2] = new DNA(ArraySequence[pos1].getSequence());
ArrayType[pos2] = ArrayType[pos1];
}
}

// transcribe function
public void transcribe(int pos1) {
if(pos1 >= size) { System.out.println("Position exceeded sequence default size");}
else if(ArrayType[pos1] == Type.RNA) { System.out.println("Cannot transcribe RNA"); } // if the info at the position is of type RNA, then print the error message and exit
else if(ArrayType[pos1] == Type.NONE) { System.out.println("No sequence to transcribe at specified position"); }
else {
ArrayType[pos1] = Type.RNA;  // iterates through and replaces every DNA variable as the RNA counterparts
String oldSeq = ArraySequence[pos1].getSequence();
String newSeq = "";
for(int i = 0; i < oldSeq.length(); i++) {
switch(oldSeq.charAt(i) + "") {
case "A":
newSeq = "U" + newSeq;
break;
case "T":
newSeq = "A" + newSeq;
break;
case "G":
newSeq = "C" + newSeq;
break;
case "C":
newSeq = "G" + newSeq;
break;
}
}
//put the new sequence into the Array
ArraySequence[pos1] = new DNA(newSeq);
}
}


  
   public static void main(String[] args) {
System.out.println(args[0]);
DnaList list = new DnaList(Integer.parseInt(args[0]));

// handle reading command from file
try {
File commandFile = new File(args[1]);
Scanner reader = new Scanner(commandFile);
while (reader.hasNextLine()) {
String commandLine = reader.nextLine();
CommandLine.processor(list, commandLine);
}
reader.close();
} catch (FileNotFoundException e) {
System.out.println("An error occurred.");
e.printStackTrace();
}
  
   }
}